# Oak Lodge Garden -- Seasonal Calendar

## Build Specification for Claude Design

---

## What this is

A new view for the Oak Lodge garden journal that answers two questions: "What's happening in the garden right now?" and "What do I need to do this month?" It sits alongside the existing Garden Plan as a second way into the same plant data, accessible from the top-level navigation.

This is not a separate app. It's a new view within the existing single-page React application, using the same design system, data structures, and component patterns already in place.

---

## Why it matters

The garden plan view is spatial -- it answers "where is everything?" The seasonal calendar answers "when does everything happen?" Brad checks the site from his phone in the garden. Right now he has to tap into each bed individually and read each plant's seasonal notes to figure out what needs attention. The calendar surfaces that information upfront, organised by time rather than location.

---

## Navigation

The existing breadcrumb bar in the header currently shows "Garden plan" as the only top-level view. Add "Seasonal calendar" as a second option.

The breadcrumb bar should work like this:

- Two top-level buttons: "Garden plan" and "Seasonal calendar"
- The active view gets the existing `aria-pressed="true"` styling (dark background, light text)
- Clicking either button switches the view and scrolls to top
- The existing bed/plant drill-down from the garden plan continues to work exactly as it does now
- The seasonal calendar is a flat view with no drill-down levels of its own

Update the `view` state in `app.jsx` to support `{ name: "calendar" }` alongside the existing `plan`, `bed`, and `plant` states.

---

## The calendar view -- structure

The view has two parts: a month selector and the month content.

### Month selector

A horizontal row of all 12 months, abbreviated (Jan, Feb, Mar, etc.). The current real-world month is selected by default when the view first loads. Tapping a month scrolls/switches to that month's content.

Style this as handwritten month tabs using the `--hand` font (Caveat). The active month should have an underline or circle treatment that feels like someone has ringed it in pencil -- not a clean UI highlight. Use `var(--accent)` for the active indicator.

On mobile, the month row should scroll horizontally if needed, with the active month scrolled into view.

### Month content

Each month's content is a single page (a `.sheet` with the paper texture) containing two sections:

**1. What's flowering / What's looking good**

A list of plants that are at their peak or notable during this month. Each entry shows:

- Plant name (in `--hand` font, as a tappable link)
- Which bed it's in (as a small `--type` font label, like "Bed 2" or "Stone Bed")
- A short note about what's happening (flowering, autumn colour, berries, winter stems, etc.)

Tapping a plant name should navigate to that plant's PlantCard, with the back button returning to the calendar view.

Group plants visually but loosely -- no rigid table. Think of how someone might jot a list in a notebook: plant name, a dash, what's happening. The bed label sits off to the side like a margin note.

**2. What needs doing**

A list of care tasks for the month. Each entry shows:

- The task (e.g. "Clip box hedging", "Deadhead roses", "Coppice dogwood")
- Which plant(s) it relates to
- Which bed

Again, this should feel like a handwritten to-do list. Consider using a checkbox style (empty squares drawn in `--pencil` colour) but purely decorative -- this isn't an interactive checklist, it's a reference.

---

## Data source -- the seasonal knowledge

The plant data lives in `data/plants.json` (and identically in `window.OAK.PLANTS` via `data.js`). Each plant has a `seasonal` field containing free-text notes about its seasonal behaviour and care timing.

The seasonal calendar needs structured month-by-month data derived from these notes. This is the critical data modelling decision.

### Recommended approach: a new data file

Create `data/seasonal.json` (and load it into `window.OAK.SEASONAL` via `data.js`) containing structured per-month data for all 36 plants. The structure:

```json
{
  "January": {
    "highlights": [
      {
        "plant": "Variegated Dogwood",
        "bed": "Bed 2",
        "note": "Bright red winter stems on full display"
      },
      {
        "plant": "Box Hedging",
        "bed": "Bed 1",
        "note": "Dense evergreen structure holds the bed shape through winter"
      }
    ],
    "tasks": [
      {
        "task": "Prune apple tree while dormant",
        "plants": ["Apple Tree"],
        "bed": "Bed 3"
      },
      {
        "task": "Prune roses hard",
        "plants": ["Rose"],
        "bed": "Bed 4"
      },
      {
        "task": "Remove dead or crossing branches from Japanese Maple",
        "plants": ["Japanese Maple"],
        "bed": "Bed 1"
      }
    ]
  }
}
```

### How to populate this data

Use the `seasonal` and `care` fields from each plant in `plants.json` to determine which months each plant is notable and what tasks apply when. Here's the full mapping, derived from the existing plant data:

**Evergreen / year-round structure plants** (always provide winter interest, highlight in quieter months):
- Box Hedging -- evergreen, clip late spring + late summer
- Euonymus (Bed 1) -- evergreen golden variegation, prune spring
- Wintercreeper (Bed 3) -- evergreen variegated, prune spring
- Japanese Aralia -- evergreen speckled leaves, protect from cold winds
- Rhododendron -- evergreen variegated, blooms late spring, deadhead after
- Houseleeks -- evergreen rosettes, almost zero maintenance
- Cordyline/Cabbage Tree -- evergreen palm-like, remove dead leaves as needed
- New Zealand Flax (both) -- evergreen sword leaves, cut old leaves spring
- Rosemary -- evergreen aromatic, prune after flowering
- Yucca -- evergreen spiky, flowers summer

**Spring highlights:**
- Aubrieta -- purple flowers spring (March-May)
- Clematis montana -- vigorous spring flowers (April-May), prune after flowering
- Weeping Cherry -- spring blossom before/with leaves (March-April)
- Pear Tree -- blossoms early spring (March-April)
- Rhododendron -- purple flowers late spring (May)
- Forget-me-not -- small blue flowers spring (April-May)
- English Daisy -- pink pom-poms early spring through summer (March onwards)
- Wisteria -- cascading flowers late spring (May)
- Hosta -- lush leaves emerge spring (April-May), watch for slugs
- Avens -- bright flowers from late spring (May onwards)

**Summer highlights:**
- Astilbe -- feathery flower plumes summer (June-August)
- Peony -- huge blooms late spring/early summer (May-June)
- Weigela -- trumpet flowers late spring/early summer (May-June)
- Rose -- flowers through summer, deadhead continuously
- Lavender -- purple flower spikes mid-late summer (July-August)
- Maiden Pink -- bright pink/red flowers summer (June-August)
- Nemesia -- flowers with second flush if trimmed (June-September)
- Silverbush -- white/pink flowers spring-summer
- Yucca -- creamy bell flowers summer (July-August)
- Stonecrop -- flowers summer
- Honeysuckle -- fragrant flowers summer, berries autumn
- Angel Wings -- silver foliage at its best spring-autumn

**Autumn highlights:**
- Japanese Maple -- autumn colour (October-November)
- Variegated Dogwood -- leaves drop to reveal red stems (October-November)
- Weeping Cherry -- yellow/bronze leaves before drop (October)
- Apple Tree -- fruit harvest late summer/autumn (August-October)
- Pear Tree -- fruit harvest late summer/autumn (August-October)
- Honeysuckle -- small berries

**Winter highlights:**
- Variegated Dogwood -- bright red stems (December-February), coppice late winter/early spring
- Box Hedging -- dense green structure
- Japanese Aralia -- tropical evergreen
- All Phormium/Cordyline -- architectural structure

**Month-by-month task calendar:**

| Month | Tasks |
|-------|-------|
| January | Prune apple tree, prune pear tree, prune roses, remove dead/crossing branches from Japanese Maple, check Cordyline for frost damage |
| February | Coppice dogwood (late Feb/early March), continue winter pruning of fruit trees, prepare supports for peony |
| March | Cut old leaves from Phormium/New Zealand Flax, prune Euonymus and Wintercreeper, mulch Clematis base, watch for box caterpillar |
| April | Watch for slugs on Hostas, start deadheading English Daisies, begin regular rose watering |
| May | Deadhead Rhododendron after flowering, prune Clematis montana after flowering, shear Aubrieta after blooming, deadhead Avens |
| June | Prune Weigela after flowering, deadhead roses, deadhead Maiden Pink, trim Nemesia after first flush, provide peony supports |
| July | Deadhead lavender (don't cut into old wood), continue deadheading roses, water Astilbe (never let dry), prune Honeysuckle after flowering |
| August | Clip box hedging (second clip), deadhead roses, harvest apples/pears if ready, trim Stonecrop if leggy |
| September | Cut back peony foliage as it dies, pull up Forget-me-nots if preventing self-seeding, harvest remaining fruit |
| October | Protect Angel Wings from first frosts, mulch Phormium crowns, tidy Houseleek rosettes, clear fallen leaves |
| November | Protect Silverbush from winter wet, final tidy of herbaceous perennials, check Clematis framework |
| December | Enjoy dogwood stems, protect tender plants from hard frost, plan any changes for spring, winter prune Wisteria |

---

## Design direction

This view should feel like the monthly pages of a garden diary. Not a dashboard, not a calendar app. A notebook page where someone has written down what to look at and what to do.

Specific design cues:

- The month name at the top of each page should be large, in `--display` font (Gloock), like a chapter heading
- Plant names in the highlights section should be in `--hand` font, slightly larger than body text
- The "what's happening" notes should be in `--serif` font (Cormorant Garamond), conversational tone
- Task items should look like handwritten list entries -- use `--hand` font with a simple bullet or checkbox glyph drawn in `--pencil` colour
- The bed labels should be in `--type` font (Special Elite), small, off to the side
- Use the existing `.rule` divider between the highlights and tasks sections
- The whole thing sits on a `.sheet` with the paper texture, exactly like the bed detail view
- Respect all five palette themes (spring, summer, autumn, winter, night) -- CSS variables handle this automatically
- Consider a small seasonal illustration or decorative element per month (optional, only if it doesn't slow down the build). If included, think pressed flowers, botanical sketches -- SVG line drawings in `var(--pencil)` colour, not photographs

---

## Mobile considerations

Brad checks this from his phone in the garden. The calendar view needs to work well on a ~375px viewport.

- Month selector: horizontal scroll, active month visible without manual scrolling
- Content: single column, no side-by-side layouts
- Plant names: large enough touch targets (minimum 44px tap area)
- Tasks list: generous spacing between items so they're easy to read while holding a phone and a pair of secateurs

---

## Technical implementation

### Files to modify

- `app.jsx` -- add calendar view state and navigation, render `SeasonalCalendar` component
- `data.js` -- add `SEASONAL` data to `window.OAK` (either inline or loaded from JSON)

### Files to create

- `SeasonalCalendar.jsx` -- the new view component
- `data/seasonal.json` -- structured month-by-month data (optional, could be inline in data.js)

### Files NOT to modify

- `paper.css` -- the design system is complete, use existing classes
- `palette.js` -- palette switching already works
- `GardenPlan.jsx` -- untouched
- `BedDetail.jsx` -- untouched
- `PlantCard.jsx` -- untouched, but the calendar should be able to open it

### Component architecture

```
SeasonalCalendar
  MonthSelector          -- horizontal month tabs
  MonthPage              -- the sheet for the selected month
    HighlightsSection    -- "What's looking good"
      PlantHighlight     -- individual plant entry (tappable)
    TasksSection         -- "What needs doing"
      TaskItem           -- individual task entry
```

### Plant card integration

When a plant name is tapped in the calendar, it needs to navigate to the PlantCard overlay. This means the calendar needs access to the same `openPlant` function used by BedDetail.

The tricky part: `openPlant` currently requires a `zoneKey` (e.g. "bed1", "bed2") to know which bed's plant list to index into. The seasonal data references beds by display name ("Bed 1", "Bed 2", "Stone Bed"). You'll need a reverse lookup from bed display name to zone key. The mapping:

| Display name | zoneKey | plantKey |
|-------------|---------|----------|
| Bed 1 | bed1 | Bed 1 |
| Bed 2 | bed2 | Bed 2 |
| Bed 3 | bed3 | Bed 3 |
| Bed 4 | bed4 | Bed 4 |
| Stone Bed | stone | Stone Bed |
| Patio | patio | Patio |
| Tree | pear | Tree |

### Script loading

Add the new JSX file to `index.html` as a `<script type="text/babel">` tag, loaded before `app.jsx` (same pattern as all other components). No build step, no bundler, no npm.

---

## What success looks like

1. Brad can tap "Seasonal calendar" in the header and see what's happening in the garden this month
2. The month selector lets him browse forward and backward through the year
3. Each month page tells him what to look at and what to do, with enough context to be useful without being overwhelming
4. Tapping a plant name takes him to the full plant card, and back returns him to the calendar
5. It looks like a page from a well-kept garden notebook, not a web app
6. It works on his iPhone in the garden
7. It respects all five palette themes
8. Adding the component doesn't break any existing functionality

---

## What to avoid

- Don't make it look like Google Calendar or any digital calendar app
- Don't use icons from icon libraries -- if you need visual elements, draw them in SVG
- Don't add a search or filter mechanism -- this is a browse-through-the-months experience
- Don't fetch any external data -- everything is static JSON
- Don't introduce any new dependencies, fonts, or CSS frameworks
- Don't create a separate HTML page -- this is a view within the existing SPA
- Don't over-engineer the data. 36 plants across 12 months is a small, manageable dataset

---

## Reference files

All source code is at: https://github.com/Gymshark-Brad/oak-lodge-garden (main branch)

| File | What it tells you |
|------|-------------------|
| `paper.css` | Complete design system -- fonts, colours, components, palette themes |
| `palette.js` | Palette switcher component and theme persistence |
| `data.js` | All zone/plant/photo data structures and bed SVG maps |
| `data/plants.json` | Raw plant data with seasonal notes (the source material for calendar content) |
| `app.jsx` | App shell, routing, view state management |
| `BedDetail.jsx` | Example of a view component within the app |
| `PlantCard.jsx` | The plant card overlay that the calendar should also be able to open |
| `DESIGN_HANDOFF.md` | Full design brief including garden layout, plant inventory, and design intent |
| `index.html` | Entry point, script loading order |
